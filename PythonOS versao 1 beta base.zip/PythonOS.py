from ursina import *
from ursina.prefabs.radial_menu import *

#####    Config da janela    #####
application.development_mode = False
window     .title            = 'PythonOS/EggOS VM'
window     .borderless       = False

##### Instancia da Ursina #####
app=Ursina()
window.fullscreen=False
numero_de_botoes=0
fundo           =Entity(model='quad',texture='TelaInicial',parent=camera.ui,scale_x=camera.aspect_ratio)
barra_de_apps   =Entity(parent=fundo,model='cube',scale=(1,.125/2,.5),y=-.46,color=color.gray)


def Menu():

    def Block():
        os.startfile(__file__+'/../Main.py')
        application.quit()

    def StandBy():
        print("To Do... :c")

    RadialMenu(buttons=(
        RadialMenuButton(text='Desligar',on_click=application.quit,color=color.red),
        RadialMenuButton(text='Bloquear',on_click=Block),
        RadialMenuButton(text='StandBy',on_click=StandBy,disabled=True),
        RadialMenuButton(text='Cancelar',color=color.red),
    ))

def AbrirApp(arquivo):
    '''Função criada para ser posta em botões (preferencialmente).

Informe a esta funcao o caminho do seu arquivo .py ou .exe (MAIN).

    Se possivel, coloque a pasta com o seu programa na pasta "Programas",
pasta essa que PythonOS vai tentar abrir.
Se encontrar-tes qualquer erro de diretorio,
recomendo que passe o path(caminho) completo do seu programa ;).'''

    try:
        os.startfile(f'{__file__}/../Programas/{arquivo}')
    except:
        os.startfile(arquivo)
    finally:
        print(f'Com licensa ae meu rapaz, nao conseguimos abrir este arquivo :c\nEsta certo? Caminho fornecido: {arquivo}')
        None



def Limpeza():
    AbrirApp(arquivo='PyCleaner PRO V2/PyCleaner PRO 2.0.py')
def Navegador():
    AbrirApp(arquivo='Navegador/main.py')
def Musica():
    AbrirApp(arquivo='PlayerDeMusica/main.py')
#0.07 de distancia
Menu      = Button(parent=barra_de_apps,model='quad',scale=(.125/2,1,.25),x=-.47,texture='Icones/python_pc.png'    ,tooltip=Tooltip('Menu')     ,on_click=Menu,color=color.white)
Navegador = Button(parent=barra_de_apps,model='quad',scale=(.125/2,1,.25),x=-.40,texture='Icones/Pasta.png'        ,tooltip=Tooltip('Navegador'),on_click=Navegador,color=color.white)
Musica    = Button(parent=barra_de_apps,model='quad',scale=(.125/2,1,.25),x=-.33,texture='Icones/Musica.png'       ,tooltip=Tooltip('Musica')   ,on_click=Musica,color=color.white)
Limpeza   = Button(parent=barra_de_apps,model='quad',scale=(.125/2,1,.25),x=-.26,texture='Icones/python_circ.png'  ,tooltip=Tooltip('Limpeza')  ,on_click=Limpeza,color=color.white)

# Menu     .on_click=None
# Navegador.on_click=None
# Musica   .on_click=None
# Limpeza  .on_click=None





camera.overlay.color=color.black
camera.overlay.animate_color(color.clear,delay=.01,duration=2)
Audio('Sons/Win7.mp3')

app.run()
##### Rodar o codigo #####