stringo = '''
-------------------------------  Limpar  OS -------------------------------
      Executa uma limpeza no seu computador, deletando arquivos inúteis.   
      _____________________________________________________________        
      |                  Vale Ressaltar:                           |       
      | Isso Limpará APENAS arquivos temporários do sistema e NÃO  |       
      |irá apagar dados seus, tais como: fotos, jogos, documentos, |       
      |músicas etc...                                              |       
      _____________________________________________________________|       
#############################################################################   




----------------------------------- VERAI -----------------------------------
      Faz uma busca por malwares no seu computador                           
      _____________________________________________________________          
      |                  Vale Ressaltar:                           |         
      | Mesmo com essa verificação oficial da Microsoft, recomenda-|         
      |mos que utilize um antivirus como Avast, McAfee ou o de sua |         
      |escolha.                                                    |         
      |NÃO RECOMENDAMOS TAMBÉM, USAR ESTE RECURSO COMO  ANTIVIRUS! |         
      |PyGirl separou dois na pasta "Para Voce".                   |         
      |____________________________________________________________|         
#############################################################################   





----------------------------------- VERAC -----------------------------------
     Realiza um escaneamento no sistema em busca de arquivos quebrados.      
     ______________________________________________________________          
     |                  Vale Ressaltar:                           |          
     | Este procedimento, NÃO IRÁ CONSERTAR programas e jogos de- |          
     |feituosos.Apenas arquivos DO SISTEMA                        |          
     _____________________________________________________________|          
#############################################################################   




-------------------------   Mini  Manutenção  ------------------------   
     Ordena que todas as tarefas anteriores sejam executadas.            
     Mais uma verificação de disco de brinde!                            
      ____________________________________________________________       
     |                  Vale Ressaltar:                           |      
     | Este procedimento, NÃO IRÁ CONSERTAR programas e jogos de- |      
     |feituosos.Apenas arquivos DO SISTEMA                        |      
     _____________________________________________________________|      
#########################################################################################
'''