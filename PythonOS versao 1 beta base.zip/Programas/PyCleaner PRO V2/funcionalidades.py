from gc import collect as limpeza_basica_de_RAM
from PySimpleGUI import popup_notify,popup_scrolled,Popup
from os import system as cmd
#😥​ 😟​ 😉​ 😒 ​😏 ​😝 ​😄 ​✔️ ​❌ ​♻️ 💾 ​📺 ​📁 ​📂​​

###############################################################################################
def LimparOS():
    cmd('cls')
    print('''
PyGirl irá executar chkdsk e cleanmgr para voce ​❤️​.
Iremos excluir 📁arquivos📁 inuteis tais como cache, despejo de memoria, logs etc...

---------   ATENÇÂO ISSO NÃO IRÁ EXCLUIR ARQUIVOS SEUS IMPORTANTES ---------

OK! Enquanto PyGirl está operando, voce sera tera por usar CLEANMGR porque eu ainda nao consigo interagir com ele...''')
    cmd('del %userprofile%Recent /q')
    cmd('del C:\Windows\Prefetch /q && del %temp%\* /q')
    print('Amor, por favor preciso que voce faça a próxima parte porque eu não consigo 😥​')
    cmd('cleanmgr')
    limpeza_basica_de_RAM()

    
###############################################################################################
def VERAI():
    cmd('cls')
    print('PyGirl está indo em busca de virus! Mas ela precisa de sua ajuda!')
    try:
        cmd('start mrt')
    except:
        cmd('.\Integrar\MRT.exe')

###############################################################################################
def VERAC():
    cmd('cls')
    print('PyGirl Está indo verificar o sistema em busca de arquivos quebrados!')
    cmd('sfc /scannow')
    print('PyGirl informou que já terminou a verificação!')
###############################################################################################
def MiniManutencao():
    cmd('cls')
    print('Iniciando TODOS os processos (um de cada vez, porque se não o seu processador e a sua memória RAM iriam ficar lentíssimos)')
    LimparOS();  VERAC();  VERAI(); print('''Agora, o toque final que ela e eu preparamos para você!
Uma verificação exclusiva de disco(HD/SSD) e memória(RAM)!(Nativa do Windows!)
que se você quiser ensinar pros seus colegas o comando está logo abaixo!
No cmd digite "chkdsk c: /f" <- c: é o volume a ser verificado!
Por exemplo um pen drive com a letra G ficaria assim: "chkdsk g: /f".

                                    Espero ter ajudado. -PyGirl & GPyDev.''')
    def verificar_se_a_verificacao_de_disco_terminou():
        cmd('chkdsk c: /f')
        return 0
    #Verificação de Disco
    vd = verificar_se_a_verificacao_de_disco_terminou()
    while(vd != 0):
        if(vd==0):
            break
    popup_notify('Verificação de disco finalizada!')
    cmd('MdSched.exe')

###############################################################################################
def Ajuda():
    from Ajuda import stringo
    popup_scrolled(stringo)
###############################################################################################
def up_no_desempenho():
    Popup('''Tudo bem, PyGirl irá te ajudar com isso!\nPyGirl: "Para dar um UP no seu desempenho, voce terá que selecionar (numa janela que abrirá) "Ajustar para melhor desempenho" e pronto!''',title='')
    cmd('SystemPropertiesPerformance.exe')
###############################################################################################
def i_need_antiV():
    cmd('explorer "Para Voce\Antivirus"')
    print('Pode escolher! ​😏 ')
