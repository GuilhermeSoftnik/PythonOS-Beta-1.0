import schedule
from PySimpleGUI import popup_notify
from time import sleep

def notificar():
    popup_notify('Acabou!')

schedule.every(30).minutes.do(notificar)
print('PyGirl o notificará quando o tempo acabar!')
while True:
    schedule.run_pending()
    sleep(1)