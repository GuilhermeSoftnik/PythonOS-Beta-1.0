from ursina import *
from PySimpleGUI import Popup
import funcionalidades

Popup('Se quiser trocar o fundo, eu e PyGirl fizemos um botão que faz isso\nOBS: o fundo não mudou? É porque como é uma seleção aleatória, ele não se preocupa em repetir. Então é só clicar novamente :)',title='AVISO')
del Popup

application.development_mode=False
app=Ursina()

########### App  Setup ############
window.borderless=False           #
window.fullscreen=False           #
window.color=color.black          #
###################################


################################################################################
lista_de_dicas=[
    Tooltip('Limpar OS = "Limpar Sistema Operacional" = Realiza uma limpeza legal no seu computador'),
    Tooltip('VERAI = "Verificar E Remover Arquivos Infectados"  = Faz uma busca a malwares'),
    Tooltip('VERAC = "Verificar E Remover Arquivos Corrompidos" = Retira do seu Computador arquivos corrompidos/quebrados'),
    Tooltip('Mini Manutenção = Executa todas as tarefas + o especial da PyGirl. "Que é uma VERIFICAÇÃO COMPLETA DE DISCO!"-PyGirl'),
    Tooltip('Fecha o programa ´-´...'),
    Tooltip('Exibe um menu de ajuda'),
    None,
    Tooltip('Abre "Propriedades avançadas" do Windows. PyGirl e Eu vamos te ajudar!'),
    Tooltip('Abre a Pasta de AntiVirus que PyGirl e Eu separamos para você!')
]

########################################  BOTOES  ########################################
LimparOS_Botao       = Button('Limpar OS'       ,scale=(.5,.2),y=0.4 ,tooltip=lista_de_dicas[0])
Verai_Botao          = Button('VeRAI'           ,scale=(.5,.2),y=0.2 ,tooltip=lista_de_dicas[1])
Verac_Botao          = Button('VeRAC'           ,scale=(.5,.2),y=0.0 ,tooltip=lista_de_dicas[2])
MiniManutencao_Botao = Button('Mini Manutenção' ,scale=(.5,.2),y=-.2 ,tooltip=lista_de_dicas[3])
Sair                 = Button('Sair'            ,scale=(.5,.2),y=-.4 ,tooltip=lista_de_dicas[4])
Ajuda_botao          = Button('PyGirl, Preciso de ajuda!',x=-.6,y=0.0,tooltip=lista_de_dicas[6],on_click=funcionalidades.Ajuda           ).fit_to_text()
Up_no_desempenho     = Button('PyGirl, Meu PC tá lento!' ,x=-.6,y=-.2,tooltip=lista_de_dicas[7],on_click=funcionalidades.up_no_desempenho).fit_to_text()
Pygirl_antivirus     = Button('PyGirl, Preciso de um Antivirus!',x=.6,y=-.2,tooltip=lista_de_dicas[8],on_click=funcionalidades.i_need_antiV).fit_to_text()

#################### Aplicar Funções  ####################
LimparOS_Botao.on_click       = funcionalidades.LimparOS
Verai_Botao.on_click          = funcionalidades.VERAI
Verac_Botao.on_click          = funcionalidades.VERAC
MiniManutencao_Botao.on_click = funcionalidades.MiniManutencao
Sair.on_click                 = application.quit

####################     Iniciar      ####################

bg = Animation('./Imagens/Apple 2.gif',parent=camera.ui,scale=(1,1.5))
app.run()
