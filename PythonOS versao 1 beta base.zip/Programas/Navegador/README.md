# Navegador simples em Python
Navegador criado para um projeto, ou seja ele é um fragmento do meu primeiro e maior projeto! Puro Python.
O projeto eu chamo de PythonOS, que é um programa, que mais tarde, eu pretendo transforma-lo em iso, tudo do absoluto 0, desde o boot até a GUI.