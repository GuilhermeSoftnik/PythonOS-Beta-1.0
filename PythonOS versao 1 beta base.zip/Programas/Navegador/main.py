from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5 import QtGui
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtPrintSupport import *
import os
import sys

class MainWindow(QMainWindow):

	def __init__(self, *args, **kwargs):
		super(MainWindow, self).__init__(*args, **kwargs)
		self.setWindowIcon(QtGui.QIcon('Pasta.png'))

		# SETUP DO NAVEGADOR
		self.browser = QWebEngineView()
		self.browser.setUrl(QUrl("https://google.com"))
		self.browser.urlChanged.connect(self.update_urlbar)
		self.browser.loadFinished.connect(self.update_title)
		self.setCentralWidget(self.browser)

		self.status = QStatusBar()
		self.setStatusBar(self.status)

		# ADICIONANDO OS BGLH
		navtb = QToolBar("Navigar na web")
		self.addToolBar(navtb)

		back_btn = QAction("Voltar", self)
		back_btn.setStatusTip("Volta a pagina anterior")
		back_btn.triggered.connect(self.browser.back)
		navtb.addAction(back_btn)

		next_btn = QAction("Avançar", self)
		next_btn.setStatusTip("Vai para a proxima pagina visitada posterior a atual")
		next_btn.triggered.connect(self.browser.forward)
		navtb.addAction(next_btn)

		reload_btn = QAction("Recarregar", self)
		reload_btn.setStatusTip("Recarregar a pagina")
		reload_btn.triggered.connect(self.browser.reload)
		navtb.addAction(reload_btn)

		home_btn = QAction("Home", self)
		home_btn.setStatusTip("Pagina inicial do browser")
		home_btn.triggered.connect(self.navigate_home)
		navtb.addAction(home_btn)
		navtb.addSeparator()

		self.urlbar = QLineEdit()
		self.urlbar.returnPressed.connect(self.navigate_to_url)
		navtb.addWidget(self.urlbar)

		# stop_btn = QAction("Stop", self)
		# stop_btn.setStatusTip("Stop loading current page")
		# stop_btn.triggered.connect(self.browser.stop)
		# navtb.addAction(stop_btn)

		self.setWindowIcon(QtGui.QIcon('Pasta.png'))
		self.show()


	def update_title(self):
		title = self.browser.page().title()
		self.setWindowTitle("% s - Navegador Python" % title)


	def navigate_home(self):
		self.browser.setUrl(QUrl("https://www.google.com"))

	def navigate_to_url(self):
		q = QUrl(self.urlbar.text())
		if q.scheme() == "":
			q.setScheme("https")
		self.browser.setUrl(q)

	def update_urlbar(self, q):
		self.urlbar.setText(q.toString())
		self.urlbar.setCursorPosition(0)


app = QApplication(sys.argv)
app.setApplicationName("Navegador Python")
window = MainWindow()
window.setWindowIcon(QtGui.QIcon('Pasta.png'))
app.exec_()
