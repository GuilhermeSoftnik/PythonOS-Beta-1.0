# coding=UTF-8

#1 Arquivo contendo a tela de login que:
#  vai me levar ate o """sistema""" principal
#  se e apenas se, as informacoes estiverem corretas
#  e em seguida fechar este programa
from ursina      import *
from PySimpleGUI import popup_notify as notify

application.development_mode=False
window.title="PythonOS/EggOS VM - Login"
window.borderless=False

app=Ursina()
window.fullscreen=False
class LoadingWheel(Entity):
    def __init__(self, **kwargs):
        super().__init__()
        self.parent = camera.ui
        self.point  = Entity(parent=self, model=Circle(24, mode='point', thickness=.03), color=color.light_gray, y=.75, scale=2*3, texture='circle')
        self.point2 = Entity(parent=self, model=Circle(12, mode='point', thickness=.03), color=color.light_gray, y=.75, scale=1*3, texture='circle')
        self.scale  = .025
        self.y      = -.25
        [setattr(self, key ,value) for key, value in kwargs.items()]

    def update(self):
        self.point.rotation_y += 5
        self.point2.rotation_y += 3


fundo  = Entity    (model='quad',   parent=camera.ui,texture='Login_IMG-OS',scale_x=camera.aspect_ratio)
nome   = InputField(text ='',y=-.3, color =color.black50)
senha  = InputField(text ='',y=-.36,color =color.black50)
entrar = Button    (text ='Entrar', scale =(.1,.04),color=color.white66,y=-.4)


def checagem():
    global nome,senha,entrar
    #Puxar dados:
    with open('dados.txt','r') as dados_extraidos_do_txt:
        dados            = dados_extraidos_do_txt.readlines()
        nome_no_arquivo  = dados[0].strip()
        senha_no_arquivo = dados[1].strip()

    def ok():
        [destroy(coisa) for coisa in [nome,senha,entrar]]
        carregamento=LoadingWheel(y=-.4)
        invoke(os.startfile,__file__+'/../PythonOS.py', delay=4)
        invoke(application.quit,delay=5)

    def errou():
        msg_de_erro=Text(
            'Senha e/ou Usuario incorretos!',
            color=color.red,  parent=camera.ui,
            scale=3,  x=-.5,  y=.25
        );destroy(msg_de_erro,delay=3)

    if ( nome.text.strip()==nome_no_arquivo and
        senha.text.strip()==senha_no_arquivo):
        ##########################       
        notify('Login aprovado')
        ok()

    else:{errou()}




entrar.on_click=checagem
def input(key):
    if key == 'enter':
        checagem()
app.run()